//Recurse over BST, for each node found, add 1. Return when branches all terminate to base case, node has no children
template<typename KeyType, typename ItemType>
int BinarySearchTree<KeyType, ItemType>::getNumberOfNodesHelper(BinaryNode<ItemType>* subTreePtr) const {
    if(subTreePtr == NULL)
        return 0;
    else
        return 1 + getNumberOfNodesHelper(subTreePtr -> getLeftChildPtr()) + getNumberOfNodesHelper(subTreePtr -> getRightChildPtr());
}


template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::insertInorder(BinaryNode<ItemType>* subTreePtr, BinaryNode<ItemType>* newNode) {
    //Tree empty or no child for previously compared node (base case)
    if(subTreePtr == NULL) {
        return newNode;
    }
    //New node greater than current node, recurse right
    else if(newNode -> getItem() > subTreePtr -> getItem()) {
        BinaryNode<ItemType>* tempPtr = insertInorder(subTreePtr -> getRightChildPtr(), newNode);
        subTreePtr -> setRightChildPtr(tempPtr);
    }
    //New node less than current node, recurse left
    else {
        BinaryNode<ItemType>* tempPtr = insertInorder(subTreePtr -> getLeftChildPtr(), newNode);
        subTreePtr -> setLeftChildPtr(tempPtr);
    }

    return subTreePtr;
}


template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::removeValue(BinaryNode<ItemType>* subTreePtr, const KeyType aKey, bool& success) {
    //Special case, tree is empty, node never found, return false
    if(subTreePtr == NULL) {
        success = false;
        return NULL;
    }
    //Current node contains aKey
    else if(subTreePtr -> getItem() == aKey) {
        //Remove node, return tree without node
        subTreePtr = removeNode(subTreePtr);
        success = true;
        return subTreePtr;
    }
    //Current node greater than aKey, recurse to nodes left child
    else if(subTreePtr -> getItem() > aKey) {
        BinaryNode<ItemType>* tempPtr = removeValue(subTreePtr -> getLeftChildPtr(), aKey, success);
        subTreePtr -> setLeftChildPtr(tempPtr);
        return subTreePtr;
    }
    //Current node less than aKey, recurse to nodes right child
    else {
        BinaryNode<ItemType>* tempPtr = removeValue(subTreePtr -> getRightChildPtr(), aKey, success);
        subTreePtr -> setRightChildPtr(tempPtr);
        return subTreePtr;
    }
}


template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::removeNode(BinaryNode<ItemType>* nodePtr) {
    //Node is leaf - delete it, return null to subTreePtr
    if(nodePtr -> isLeaf() == true) {
        delete nodePtr;
        nodePtr = NULL;
        return nodePtr;
    }
    //Node has only one child
    else if((nodePtr -> getLeftChildPtr() == NULL && nodePtr -> getRightChildPtr() != NULL) || (nodePtr -> getRightChildPtr() == NULL && nodePtr -> getLeftChildPtr() != NULL)) {
        BinaryNode<ItemType>* nodeToConnectPtr;
        //Get node's child
        if(nodePtr -> getLeftChildPtr() != NULL)
            nodeToConnectPtr = nodePtr -> getLeftChildPtr();

        else
            nodeToConnectPtr = nodePtr -> getRightChildPtr();

        //Delete node
        delete nodePtr;
        nodePtr = NULL;
        //Return node's child to parent
        return nodeToConnectPtr;
    }
    //Node has two children
    else {
        ItemType inorderSuccessor;
        //Find Inorder Successor node, return its entry to temporary pointer, delete original Inorder Successor node
        BinaryNode<ItemType>* tempPtr = removeLeftmostNode(nodePtr -> getRightChildPtr(), inorderSuccessor);
        nodePtr -> setRightChildPtr(tempPtr);
        //Change node's Item to Inorder Successor's Item
        nodePtr -> setItem(inorderSuccessor);
    }
}

//Find inorder successor node recursively. Copy its ItemType. Remove its node
template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::removeLeftmostNode(BinaryNode<ItemType>* subTreePtr, ItemType& inorderSuccessor) {
    //Inorder successor found
    if(subTreePtr -> getLeftChildPtr() == NULL) {
        inorderSuccessor = subTreePtr -> getItem();
        return removeNode(subTreePtr);
    }
    //Inorder not found, recurse
    else {
        subTreePtr -> setLeftChildPtr(removeLeftmostNode(subTreePtr -> getLeftChildPtr(), inorderSuccessor));
        return subTreePtr;

    }
}


//Recursively find node with KeyType target by performing comparisons
template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::findNode(BinaryNode<ItemType>* treePtr, KeyType& aKey) const
{
    //Tree is empty, return null
    if(treePtr == NULL)
       return NULL;
    //Found node
    else if(treePtr -> getItem() == aKey)
        return treePtr;
    //Current node greater than target, recurse left
    else if(treePtr -> getItem() > aKey)
        return findNode(treePtr -> getLeftChildPtr(), aKey);
    //Current node less than target, recurse right
    else
        return findNode(treePtr -> getRightChildPtr(), aKey);
}

//Helper for preorder traverse - visit root, left subTree, right subTree recursively
template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::preorder(void visit(ItemType&), BinaryNode<ItemType>* treePtr) const {
    if(treePtr != NULL) {
        ItemType theItem = treePtr -> getItem();
        visit(theItem);
        preorderHelper(visit, treePtr -> getLeftChildPtr());
        preorderHelper(visit, treePtr -> getRightChildPtr());
    }
}

//Helper for postorder traverse - visit left subTree, right subTree, root recursively
template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::postorder(void visit(ItemType&), BinaryNode<ItemType>* treePtr) const {
    if(treePtr != NULL) {
        postorderHelper(visit, treePtr -> getLeftChildPtr());
        postorderHelper(visit, treePtr -> getRightChildPtr());
        ItemType theItem = treePtr -> getItem();
        visit(theItem);
    }
}



//Helper for inorder traverse - visit left subTree, root, right subTree recursively
template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::inorder(void visit(ItemType&), BinaryNode<ItemType>* treePtr) const {
    if(treePtr != NULL) {
        inorderHelper(visit, treePtr -> getLeftChildPtr());
        ItemType theItem = treePtr -> getItem();
        visit(theItem);
        inorderHelper(visit, treePtr -> getRightChildPtr());
    }
}



//public methods

template<typename KeyType, typename ItemType>
BinarySearchTree<KeyType, ItemType>::BinarySearchTree(): rootPtr(NULL) {
}

//Copy constructor, utilizes copyTree helper method
template<typename KeyType, typename ItemType>
BinarySearchTree<KeyType, ItemType>::BinarySearchTree(const BinarySearchTree<KeyType, ItemType>& tree) {
    rootPtr = copyTree(tree.rootPtr);
}
template<typename KeyType, typename ItemType>
BinarySearchTree<KeyType, ItemType>::BinarySearchTree(const ItemType& rootItem)
{
rootPtr = new BinaryNode<ItemType>(rootItem);
}


//Recursively copy each node of the tree
template<typename KeyType, typename ItemType>
BinaryNode<ItemType>* BinarySearchTree<KeyType, ItemType>::copyTree(const BinaryNode<ItemType>* treePtr) const {
    BinaryNode<ItemType>* newTreePtr = NULL;

    if(treePtr != NULL) {
        //Create new tree node
        newTreePtr = new BinaryNode<ItemType>(treePtr -> getItem(), NULL, NULL);
        //Copy old tree's left and right children
        newTreePtr -> setLeftChildPtr(copyTree(treePtr -> getLeftChildPtr()));
        newTreePtr -> setRightChildPtr(copyTree(treePtr -> getRightChildPtr()));
    }

    return newTreePtr;
}



//Destructor, utilizes destroyTree helper method
template<typename KeyType, typename ItemType>
BinarySearchTree<KeyType, ItemType>::~BinarySearchTree() {
    destroyTree(rootPtr);
}

//Recurse over each branch, delete nodes
template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::destroyTree(BinaryNode<ItemType>* subTreePtr) {
    if(subTreePtr != NULL) {
        destroyTree(subTreePtr -> getLeftChildPtr());
        destroyTree(subTreePtr -> getRightChildPtr());
        delete subTreePtr;
    }
}


template<typename KeyType, typename ItemType>
bool BinarySearchTree<KeyType, ItemType>::isEmpty() const {
    return (rootPtr == NULL);
}


template<typename KeyType, typename ItemType>
int BinarySearchTree<KeyType, ItemType>::getHeight() const {
    return getHeightHelper(rootPtr);
}

template<typename KeyType, typename ItemType>
int BinarySearchTree<KeyType,ItemType>::getHeightHelper(BinaryNode <ItemType>* subTreePtr) const
{
if (subTreePtr==NULL) {
  return 0;

}
else
      return 1+max(getHeightHelper(subTreePtr->getLeftChildPtr()),getHeightHelper(subTreePtr->getRightChildPtr()));

}


template<typename KeyType, typename ItemType>
int BinarySearchTree<KeyType, ItemType>::getNumberOfNodes() const {
    return getNumberOfNodesHelper(rootPtr);
}


//Insert new node with entry newEntry into BST - utilizes inorderInsertion helper method
template<typename KeyType, typename ItemType>
bool BinarySearchTree<KeyType, ItemType>::add(const ItemType& newEntry) {
    BinaryNode<ItemType>* newNodePtr = new BinaryNode<ItemType>(newEntry);
    rootPtr = insertInorder(rootPtr, newNodePtr);
}

template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::remove(const KeyType& aKey) throw(NotFoundException)
{
    bool success = false;
    rootPtr = removeValue(rootPtr, aKey, success);

    if(success == false)
        throw NotFoundException("key not found");

}



template<typename KeyType, typename ItemType>
ItemType BinarySearchTree<KeyType, ItemType>::getEntry(const KeyType& aKey) const throw(NotFoundException) {
    BinaryNode<ItemType>* foundPtr = findNode(rootPtr, aKey);
    if(foundPtr == NULL)
        throw NotFoundException("key not found");
    else
        return foundPtr -> getItem();
}

template<typename KeyType, typename ItemType>
bool BinarySearchTree<KeyType, ItemType>::contains(const KeyType& aKey) const {
    if(findNode(rootPtr, aKey) != NULL)
        return true;
    else
        return false;
}


template<typename KeyType, typename ItemType>
void BinarySearchTree<KeyType, ItemType>::setEntry(const KeyType& aKey, const ItemType& item) const throw(NotFoundException)
{

BinaryNode<ItemType>* foundPtr = findNode(rootPtr, aKey);
if(foundPtr == NULL)
    throw NotFoundException("key not found");
else
    return foundPtr -> setItem(item);


}
