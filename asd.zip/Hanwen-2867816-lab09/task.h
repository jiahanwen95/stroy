#ifndef TASK_H
#define TASK_H
#include <iostream>
#include <istream>
#include <ostream>
#include <string>
using namespace std;
class task
{
	private:
    int taskID;
    string taskName;
    int estimatedTimeToComplete;
    int timeAddedToBST;
    int timeStarted;

	public:
		task();
		void setName(string name);
		int setID(int id);
		int setBSTtime(int time);
		int setStime(int starttime);
		int setestime(int time);

		string getName();
		int getID();
		int getBSTtime();
		int getStime();
    int getestime();
void printrecord();

//BinarySearchTree<int,task> asd
















};
#endif
