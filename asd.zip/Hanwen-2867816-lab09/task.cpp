#include "task.h"
task::task()
{
  taskID=0;
  //taskName=" ";
  //estimatedTimeToComplete=0;
  //timeAddedToBST=0;
  //timeStarted=0;
}
void task::setName(string name)
{
  taskName=name;
}

int task::setID(int id)
{
  taskID=id;
}

int task::setestime(int time)
{
  estimatedTimeToComplete=time;
}

int task::setBSTtime(int time)
{
  timeAddedToBST=time;//if not started start it and equal to currenttime;
}

int task::setStime(int starttime)
{
  timeStarted=starttime;//check it is start or not;
}

string task::getName()
{
return taskName;
}

int task::getID()
{
  return taskID;
}

int task::getStime()
{
  return timeStarted;
}

int task::getestime()
{
  return estimatedTimeToComplete;
}

void task::printrecord()
{
cout<<taskID<<endl;
cout<<taskName<<endl;
cout<<timeAddedToBST<<endl;
//cout<<timeStarted<<endl;
}
