/*
@File Name: Executive.h
@Author: Hanwen Jia
@Assignment: EECS-268 Lab8
@Description: this file defines all the function in Executive.h
@Date: 11/14/2018
*/
#ifndef EXECUTIVE_H
#define EXECUTIVE_H
#include "BinarySearchTree.h"
#include "BinaryNode.h"
#include "task.h"
#include <iostream>
#include <string>
#include <fstream>
using namespace std;
class Executive
{
   fstream inFile;
   BinarySearchTree<int,int> project;
   string command;
   int taskid;
   string taskname;
   int esttime;
  public:
//@pre a command postfix or prefix, and a filename
   //@post check the file and choose function by command
   //@return print three order of content
  void run( string fileName);
  //@pre none
   //@post none
   //@return none
  Executive();

};
#endif
