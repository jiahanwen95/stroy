#include <iostream>
#include <fstream>
#include <string>
#include "Executive.h"

int main(int argc, char* argv[])
{
   string filename;
  filename="1.txt";

    Executive project;
    project.run(filename);



}
