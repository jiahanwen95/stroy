#include "Executive.h"
#include <iostream>
#include <fstream>
#include "BinarySearchTree.h"
using namespace std;

Executive::Executive()
{
}

void Executive::run(string fileName)
{
  //project=new BinarySearchTree<int,int>();
  inFile.open(fileName);
  if (!(inFile.is_open()))
  {
         cout<<"invalid file";

  }
  else{


   inFile>>command;
   if(command== "add")
   {
  task temp;
  inFile>>taskid;
  inFile>>taskname;
  inFile>>esttime;
  temp.setID(taskid);
  temp.setName(taskname);
  temp.setestime(esttime);
  //temp.add(taskid);
  //temp.printrecord();
  project.add(40);
  project.add(30);
  project.add(20);

  cout<<project.getHeight()<<endl;
  project.remove(30);
  cout<<project.getHeight()<<endl;
  project.getEntry(40);
  
   //project.contains(40);
   }







  }
}
